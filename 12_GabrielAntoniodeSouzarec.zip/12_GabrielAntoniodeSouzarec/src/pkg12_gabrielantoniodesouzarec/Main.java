package pkg12_gabrielantoniodesouzarec;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner menu = new Scanner(System.in);
        int check = 0, expresso = 0, capuccino = 0, comLeite = 0, total = 0;
        double dinheiro = 0.0;
        
        while (check == 0){
            System.out.println("Selecione o pedido/operação que deseja realizar: \n");
            System.out.println(" 1: Café Expresso \n 2: Capuccino \n 3: Leite com Café \n 4: Relatório de Vendas");
            
            int opcao = menu.nextInt();
            
            switch(opcao){
                case 1:
                    System.out.println("Você selecionou Café Expresso!");
                    dinheiro += 0.75;
                    expresso +=1;
                    break;
                
                case 2:
                    System.out.println("Você selecionou Capuccino!");
                    dinheiro += 1.00;
                    capuccino += 1;
                    break;
                        
                case 3:
                    System.out.println("Você selecionou Leite com Café!");
                    dinheiro += 1.25;
                    comLeite += 1;
                    break;
                
                case 4:
                    total = expresso + capuccino + comLeite;
                    System.out.println("A venda de café do dia foi de " +expresso+ "Cafés Expressos, " +capuccino+ "Capuccinos, " +comLeite+ "Cafés com Leite. A venda do dia foi de " +total+ " Cafés e o Lucro foi de: R$" +dinheiro);
                    check = 1;
                    menu.close();
                    break;
                
                default:
                    System.err.println("Operação inválida, selecione uma operação.");
                    break;
            }
        }
    }
    
}
