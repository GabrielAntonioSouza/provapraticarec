package pkg17_gabrielantoniodesouzarec;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
         Scanner ler = new Scanner(System.in);
    int i, n;
    Date dataHoraAtual = new Date();
    String data = new SimpleDateFormat("dd/MM/yyyy").format(dataHoraAtual);

    System.out.printf("Informe o número para a tabuada:\n");
    n = ler.nextInt();

    FileWriter arq = new FileWriter("C:\\Users\\aluno\\Desktop\\tabuada de "+n+".txt");
    PrintWriter gravarArq = new PrintWriter(arq);
    
     gravarArq.println("Tabuada de: " +n);
     gravarArq.println("---Data---" + data);
      

    gravarArq.printf("+--Resultado--+%n");
    for (i=1; i<=10; i++) {
      gravarArq.printf("| %2d X %d = %2d |%n", i, n, (i*n));
    }
    gravarArq.printf("+-------------+%n");

    arq.close();
    }
    
}
