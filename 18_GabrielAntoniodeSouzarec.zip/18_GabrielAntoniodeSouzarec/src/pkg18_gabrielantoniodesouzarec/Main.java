package pkg18_gabrielantoniodesouzarec;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Insira o nome do Lutador: ");
        String nome = scanner.nextLine();
        
        System.out.println("Insira o peso do Lutador: ");
        double peso = scanner.nextInt();
        
        FileWriter arq = new FileWriter("C:\\Users\\aluno\\Desktop\\Lutadores.txt");
        PrintWriter gravararq = new PrintWriter(arq);
        
        if(peso <65){
           gravararq.printf("Nome Fornecido: " +nome);
            
           gravararq.printf("Peso Fornecido: " +peso);
            
           gravararq.printf("O Lutador " +nome+ " pesa " +peso+ "kg e se enquadra na categoria Pena.");
        }else if(peso >=65 && peso<72){
           gravararq.printf("Nome Fornecido: " +nome);
            
           gravararq.printf("Peso Fornecido: " +peso);
            
           gravararq.printf("O Lutador " +nome+ " pesa " +peso+ "kg e se enquadra na categoria Leve.");
        }else if(peso >=72 && peso<79){
           gravararq.printf("Nome Fornecido: " +nome);
            
           gravararq.printf("Peso Fornecido: " +peso);
            
           gravararq.printf("O Lutador " +nome+ " pesa " +peso+ "kg e se enquadra na categoria Ligeiro.");
        }else if(peso >=79 && peso<86){
           gravararq.printf("Nome Fornecido: " +nome);
            
           gravararq.printf("Peso Fornecido: " +peso);
            
           gravararq.printf("O Lutador " +nome+ " pesa " +peso+ "kg e se enquadra na categoria Meio Médio.");
        }else if(peso >=86 && peso<93){
           gravararq.printf("Nome Fornecido: " +nome);
            
           gravararq.printf("Peso Fornecido: " +peso);
            
           gravararq.printf("O Lutador " +nome+ " pesa " +peso+ "kg e se enquadra na categoria Médio.");
        }else if(peso >=93 && peso<100){
           gravararq.printf("Nome Fornecido: " +nome);
            
           gravararq.printf("Peso Fornecido: " +peso);
            
           gravararq.printf("O Lutador " +nome+ " pesa " +peso+ "kg e se enquadra na categoria Meio Pesado.");
        }else if(peso >=100){
           gravararq.printf("Nome Fornecido: " +nome);
            
           gravararq.printf("Peso Fornecido: " +peso);
            
           gravararq.printf("O Lutador " +nome+ " pesa " +peso+ "kg e se enquadra na categoria Pesado.");
        }
        arq.close();
    }
    
}
